import json
import boto3
import os
DTable = os.environ['Table']
# import requests


def lambda_handler(event, context):
    print(event)
    if os.getenv("AWS_SAM_LOCAL"):
        dynamodb = boto3.resource('dynamodb', endpoint_url="http://dynamodb:8000")
    else:
        #Just tring with both client and resource, depending on situation use one
        dynamodb = boto3.resource('dynamodb')
        dynamodb_client = boto3.client('dynamodb')
    table = dynamodb.Table(DTable)
    idvalue = event['queryStringParameters']['id']
    namev = event['queryStringParameters']['namev']

    if event['httpMethod'] == "POST":
      
        response = table.put_item(
            Item={
                'id': int(idvalue),
                'namev': namev,
                'email': "testEmail@gmail.com"
                }
            )
        print("DynamoDB loaded with data")
        resp = "response: " + "DynamoDB loaded with data"
    else:
        response = dynamodb_client.query(
            TableName=DTable,
            #Filter expression for incuding non key attributes in query condition
            #FilterExpression =""
            ExpressionAttributeValues={
                ":idvalue": {'N':idvalue},
                ":namevalue": {'S':namev}
            },
            #Projection expression for returning only mentioned fields
            #ProjectionExpression='columnname',
            KeyConditionExpression="id= :idvalue and begins_with(namev,:namevalue)"
        )

        item = response['Items']
        print(item)
        resp = "response: " + str(item)

    
    """Sample pure Lambda function
    
    Parameters
    ----------
    event: dict, required
        API Gateway Lambda Proxy Input Format

        Event doc: https://docs.aws.amazon.com/apigateway/latest/developerguide/set-up-lambda-proxy-integrations.html#api-gateway-simple-proxy-for-lambda-input-format

    context: object, required
        Lambda Context runtime methods and attributes

        Context doc: https://docs.aws.amazon.com/lambda/latest/dg/python-context-object.html

    Returns
    ------
    API Gateway Lambda Proxy Output Format: dict

        Return doc: https://docs.aws.amazon.com/apigateway/latest/developerguide/set-up-lambda-proxy-integrations.html
    """

    # try:
    #     ip = requests.get("http://checkip.amazonaws.com/")
    # except requests.RequestException as e:
    #     # Send some context about this error to Lambda Logs
    #     print(e)

    #     raise e

    return {
        "statusCode": 200,
        "headers": {'Access-Control-Allowed-origin':"*"},
        "body": json.dumps({
            "message": "hello world test-lambda",
            "response": resp
            # "location": ip.text.replace("\n", "")
        }),
    }
